# math_module_calculations.py

import math

try:
    num = float(input("Enter a number: "))
    print("Square Root:", math.sqrt(num))
    print("Natural Logarithm (log base e):", math.log(num))
    print("Sine (in radians):", math.sin(num))
except ValueError:
    print("Invalid input! Please enter a valid number.")
except Exception as e:
    print("An error occurred:", e)