# Python Assignment 3: Functions & Modules

This repository contains two Python programs based on Module 4: Functions and Modules in Python.

## ✅ Task 1: Calculate Factorial Using a Function
- Defines a function named `factorial` to calculate the factorial of a given number.
- Uses a loop to compute the factorial.
- Prints the result for a sample input (e.g., 5).

### 🔸 Example Output:
```
Factorial of 5 is 120
```

## ✅ Task 2: Using Math Module for Calculations
- Takes a number input from the user.
- Uses `math` module to calculate:
  - Square root
  - Natural logarithm (log base e)
  - Sine (in radians)
- Displays the results.

### 🔸 Example Output (Input = 25):
```
Square Root: 5.0
Natural Logarithm: 3.2188758248682006
Sine: -0.13235175009777303
```

## ▶️ How to Run:
1. Download or clone this repository.
2. Run:
```bash
python factorial_function.py
python math_module_calculations.py
```